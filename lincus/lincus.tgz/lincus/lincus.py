import argparse
import logging
import sys
import argcomplete

from config import VERSION
from commands import install_cmd, list_cmd, start_cmd, stop_cmd, uninstall_cmd, save_cmd, clear_cmd

# Logger configuration
logging.basicConfig(
    format='[%(levelname)s] - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


def print_help(parser, subparsers):
    """
    Muestra los comandos disponibles y sus descripciones.
    """
    print(parser.description)
    print("Available commands:")

    # Iteramos sobre los subparsers y mostramos los comandos registrados
    for subcommand in subparsers._actions:
        if isinstance(subcommand, argparse._SubParsersAction):
            # Iteramos sobre los comandos registrados dentro de subparsers
            for choice, subparser in subcommand.choices.items():
                print(f"    {choice:<15} {subparser.description}")

     # Mostrar los flags disponibles
    print("\nFlags:")
    for action in parser._actions:
        # Solo mostrar flags, no subcomandos
        if action.dest != "command" and action.option_strings:
            options = ", ".join(action.option_strings)
            print(f"    {options:<15} {action.help}")

    print(parser.epilog)


def main():
    # Argument parser
    parser = argparse.ArgumentParser(
        prog="lincus",
        description="Lincus: a tool for running LINCUS scenarios.",
        epilog="Use 'lincus <command> --help' for more information on a specific command.",
        add_help=False  # Desactivamos la ayuda automática para personalizarla
    )

    # lincus commands
    subparsers = parser.add_subparsers(dest="command")

    # Register commands
    install_cmd.register_subcommand(subparsers)
    list_cmd.register_subcommand(subparsers)
    start_cmd.register_subcommand(subparsers)
    stop_cmd.register_subcommand(subparsers)
    uninstall_cmd.register_subcommand(subparsers)
    save_cmd.register_subcommand(subparsers)
    clear_cmd.register_subcommand(subparsers)

    # Print version
    parser.add_argument(
        '-v',
        '--version',
        action='store_true',
        help="Print version number."
    )

    argcomplete.autocomplete(parser)
    # Arguments parsing
    args = parser.parse_args()

    # If no args are passed, show help and exit
    if len(sys.argv) == 1:
        print_help(parser, parser._subparsers)
        sys.exit(0)

    # if version argument, print version and exit (ignores all possible commands)
    if args.version:
        print(VERSION)
        sys.exit(0)

    if args.command == "install":
        install_cmd.execute(args, logger)
    elif args.command == "list":
        list_cmd.execute(args, logger)
    elif args.command == "start":
        start_cmd.execute(args, logger)
    elif args.command == "stop":
        stop_cmd.execute(args, logger)
    elif args.command == "uninstall":
        uninstall_cmd.execute(args, logger)
    elif args.command == "save":
        save_cmd.execute(args, logger)
    elif args.command == "clear":
        clear_cmd.execute(args, logger)
    else:
        parser.print_help(parser, parser._subparsers)
        sys.exit(1)


if __name__ == "__main__":
    main()
