incus_shell() {
  if [ -z "$1" ]; then
    echo "Usage: incus shell <instance_name>"
    return 1
  fi
  INSTANCE_NAME=$1
  incus exec "$INSTANCE_NAME" -- sh -c "export PS1='${INSTANCE_NAME} \$ '; exec sh"
}
