#!/bin/bash

# Sourcing de scripts individuales
for script in /opt/lincus/scripts/*.sh; do
    if [[ "$script" != */lincus-scripts.sh ]]; then
        source "$script"
    fi
done
