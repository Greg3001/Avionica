#!/bin/bash

# --- vtysh helper ---
vtysh() {
    if [ "$#" -lt 1 ]; then
        echo "Usage:"
        echo "  vtysh <router>                      → abre vtysh en ese router"
        echo "  vtysh <router> -c '<cmd1 ; cmd2>'   → ejecuta comandos dentro de vtysh"
        echo "  vtysh -h | --help                   → muestra esta ayuda"
        return 1
    fi

    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        echo "Usage:"
        echo "  vtysh <router>                      → abre vtysh en ese router"
        echo "  vtysh <router> -c '<cmd1 ; cmd2>'   → ejecuta comandos dentro de vtysh"
        echo "  vtysh -h | --help                   → muestra esta ayuda"
        return 0
    fi

    local router="$1"

    if [ "$2" = "-c" ]; then
        if [ -z "$3" ]; then
            echo "Error: debes especificar un comando tras -c"
            return 1
        fi

        IFS=';' read -ra commands <<< "$3"
        for cmd in "${commands[@]}"; do
            incus exec "$router" -- vtysh -c "${cmd}"
        done
    else
        incus exec "$router" -- vtysh
    fi
}
