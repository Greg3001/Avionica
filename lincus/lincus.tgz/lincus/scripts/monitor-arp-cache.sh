#!/bin/bash

monitor_arp_cache() {
    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        echo "Usage:"
        echo "  monitor_arp_cache <router> <output_file>"
        echo
        echo "Descripción:"
        echo "  Monitoriza la tabla ARP de una instancia de Incus cada segundo,"
        echo "  mostrando la salida en pantalla y guardándola en un fichero."
        return 0
    fi

    if [ "$#" -ne 2 ]; then
        echo "Error: número incorrecto de argumentos"
        echo "Uso: monitor_arp_cache <router> <output_file>"
        echo "Consulta monitor_arp_cache --help para más información."
        return 1
    fi

    local router="$1"
    local logfile="$2"

    echo "Iniciando monitorización de la caché ARP de '$router'."
    echo "Los resultados se guardarán en '$logfile'."
    echo "Pulsa Ctrl+C para detener."

    while true; do
        clear
        incus exec "$router" -- sh -c 'echo -n "`date +[%H:%M:%S]` "; ip neigh' | tee -a "$logfile"
        sleep 1
    done
}
