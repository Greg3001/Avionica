# yaml_utils.py

import yaml

def setup_multiline_str():
    """
    Configura PyYAML para que las cadenas con saltos de línea
    se representen con estilo literal (|) al hacer yaml.dump().
    """
    def str_presenter(dumper, data):
        if '\n' in data:  # Si la cadena tiene saltos de línea
            return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
        return dumper.represent_scalar('tag:yaml.org,2002:str', data)

    yaml.add_representer(str, str_presenter)
