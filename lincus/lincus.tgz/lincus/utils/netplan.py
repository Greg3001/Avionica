import ipaddress
import re

def interfaces_to_netplan(config: str) -> dict:
    netplan = {
        "ethernets": {},
        "version": 2
    }

    interfaces = {}
    auto_interfaces = set()
    current_iface = None

    for line in config.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        if line.startswith("auto"):
            auto_interfaces.update(line.split()[1:])
            continue

        if line.startswith("allow-hotplug"):
            # Hotplug interfaces can also be treated as "auto" for simplicity
            auto_interfaces.update(line.split()[1:])
            continue

        iface_match = re.match(r"iface (\S+) inet (\S+)", line)
        if iface_match:
            current_iface, method = iface_match.groups()
            interfaces[current_iface] = {
                "method": method,
                "addresses": [],
                "nameservers": {
                    "addresses": [],
                    "search": []
                },
                "routes": [],
                "raw": []
            }
            continue

        if current_iface:
            parts = line.split()
            key = parts[0]
            values = parts[1:]

            # Store unrecognized options for traceability
            if key not in ("address", "netmask", "gateway", "dns-nameservers",
                           "dns-search", "up", "down", "pre-up", "post-down"):
                interfaces[current_iface]["raw"].append(line)
                continue

            iface = interfaces[current_iface]

            if key == "address":
                iface["addresses"].append(values[0])  # CIDR will be set after netmask
            elif key == "netmask":
                if iface["addresses"]:
                    ip = iface["addresses"][-1]
                    network = ipaddress.IPv4Network(f"{ip}/{values[0]}", strict=False)
                    iface["addresses"][-1] = f"{ip}/{network.prefixlen}"
            elif key == "gateway":
                iface["gateway4"] = values[0]
            elif key == "dns-nameservers":
                iface["nameservers"]["addresses"].extend(values)
            elif key == "dns-search":
                iface["nameservers"]["search"].extend(values)
            elif key == "up" and "ip route add" in line:
                # Example: up ip route add 192.168.2.0/24 via 192.168.1.1
                route_match = re.search(r"ip route add (\S+) via (\S+)", line)
                if route_match:
                    to, via = route_match.groups()
                    iface["routes"].append({"to": to, "via": via})

    # Ahora convertimos al formato de Netplan
    for iface_name, cfg in interfaces.items():
        if iface_name == "lo":
            continue
        netplan_iface = {}
        method = cfg["method"]

        if method == "dhcp":
            netplan_iface["dhcp4"] = True
        elif method == "static":
            netplan_iface["dhcp4"] = False
            if cfg["addresses"]:
                netplan_iface["addresses"] = cfg["addresses"]
            if "gateway4" in cfg:
                netplan_iface["gateway4"] = cfg["gateway4"]
        elif method == "manual":
            netplan_iface["dhcp4"] = False
        else:
            netplan_iface["raw-method"] = method  # Método no soportado directamente

        if cfg["nameservers"]["addresses"] or cfg["nameservers"]["search"]:
            netplan_iface["nameservers"] = {}
            if cfg["nameservers"]["addresses"]:
                netplan_iface["nameservers"]["addresses"] = cfg["nameservers"]["addresses"]
            if cfg["nameservers"]["search"]:
                netplan_iface["nameservers"]["search"] = cfg["nameservers"]["search"]

        if cfg["routes"]:
            netplan_iface["routes"] = cfg["routes"]

        if cfg["raw"]:
            netplan_iface["x-unparsed"] = cfg["raw"]

        netplan["ethernets"][iface_name] = netplan_iface

    return netplan
