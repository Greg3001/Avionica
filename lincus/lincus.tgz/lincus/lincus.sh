#!/bin/bash
# Obtener la ruta absoluta del script
SCRIPT_DIR=$(dirname "$(readlink -f "$0")")

# Llamada al script Python usando la ruta absoluta al script
python "$SCRIPT_DIR/lincus.py" "$@"
