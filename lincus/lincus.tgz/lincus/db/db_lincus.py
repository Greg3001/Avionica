import sqlite3

def is_any_scenario_running(conn):
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM SCENARIOS WHERE RUNNING = 1 LIMIT 1")
        return cursor.fetchone() is not None
    except sqlite3.Error as e:
        raise RuntimeError(f"Error checking running scenario: {e}") from e

def get_scenario_path(db_path,scenario_id):
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute(f"SELECT PATH FROM SCENARIOS WHERE ID = '{scenario_id}'")
        row = cursor.fetchone()

        if not row:
            return None  # No había ningún escenario en ejecución

        scenario_path = row[0]

        return scenario_path

    except sqlite3.Error as e:
        raise RuntimeError(f"Error getting path from scenario '{scenario_id}': {e}") from e
    

def set_scenario_running(db_path, scenario_id):
    try:
        conn = sqlite3.connect(db_path)
        if not is_any_scenario_running(conn):
            cursor = conn.cursor()
            cursor.execute("UPDATE SCENARIOS SET RUNNING = 1 WHERE ID = ?", (scenario_id,))
            conn.commit()
            return True
        return False
    except sqlite3.Error as e:
        raise RuntimeError(f"Error updating scenario '{scenario_id}': {e}") from e
    
def get_running_scenario(db_path):
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Buscar si hay uno en ejecución
        cursor.execute("SELECT ID FROM SCENARIOS WHERE RUNNING = 1")
        row = cursor.fetchone()

        if not row:
            return None  # No había ningún escenario en ejecución

        scenario_id = row[0]

        return scenario_id

    except sqlite3.Error as e:
        raise RuntimeError(f"Error resetting running scenario: {e}") from e
    
def reset_running_scenario(db_path):
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Buscar si hay uno en ejecución
        cursor.execute("SELECT ID FROM SCENARIOS WHERE RUNNING = 1")
        row = cursor.fetchone()

        if not row:
            return None  # No había ningún escenario en ejecución

        scenario_id = row[0]

        # Poner RUNNING = 0
        cursor.execute("UPDATE SCENARIOS SET RUNNING = 0 WHERE ID = ?", (scenario_id,))
        conn.commit()

        return scenario_id

    except sqlite3.Error as e:
        raise RuntimeError(f"Error resetting running scenario: {e}") from e
    
    finally:
        conn.close()

def does_scenario_exist(db_path, scenario_id):
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM SCENARIOS WHERE ID = ?", (scenario_id,))
        # Si existe, cursor.fetchone() devolverá una fila (no None)
        return cursor.fetchone() is not None
    except sqlite3.Error as e:
        raise RuntimeError(f"Error checking if scenario exists: {e}") from e
    finally:
        conn.close()