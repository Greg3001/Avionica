VERSION = "0.0.1"
LABS_PATH = "/opt/lincus/labs"

BACKUP_TEMPLATES = {}

IMAGES_PRIORITIES = {
    "router": 0,
    "simple-host": 1
}

IMAGES_NCM = {
    "router": "ifupdown",
    "simple-host": "ifupdown"
}

CLR_REGEXP = {
    "instances": [r"R\d{2}", r"H\d{2}"],
    "networks": [r"br\d{2}"]
}
