import subprocess
import yaml

from pathlib import Path
import os


def createNetwork(network, type, config):
    args = ['incus', 'network', 'create', network, '-t', type]
    for c in config:
        args.append(f'{c}={config[c]}')
    subprocess.run(args, stdout=subprocess.DEVNULL)


def deleteNetwork(network):
    args = ['incus', 'network', 'delete', network]
    subprocess.run(args, stdout=subprocess.DEVNULL)


def createInstance(name, instance, network_config_path): #, user_data_path):
    image = instance["incus"]["source"]["alias"]
    #args = ['incus', 'launch', image, name]
    args = ['incus', 'create', image, name]

    if instance['incus']['ephemeral']:
        args.append('-e')

    for profile in instance['incus']['profiles']:
        args.append('-p')
        args.append(profile)

    with open(network_config_path, 'r') as f:
        network_config_str = f.read()

    #with open(user_data_path, 'r') as f:
    #    user_data_str = f.read()

    args.append('--config')
    args.append(f'cloud-init.network-config={network_config_str}')
    #args.append('--config')
    #args.append(f'cloud-init.user-data={user_data_str}')

    devices = {"devices": instance['incus']['devices']}
    incus_config = instance['incus'].setdefault('config', {})
    properties = {"config": incus_config}

    # devices["devices"] = yaml.dump(instance['incus']['devices'])
    devices_yaml = yaml.dump(devices)

    config = devices | properties
    config_yaml = yaml.dump(config)
    #print(config_yaml)
    subprocess.run(args, input=bytes(config_yaml, 'utf-8'),
                   stdout=subprocess.DEVNULL)
    #wait_args = ["incus", "exec", name, "--", "cloud-init", "status", "--wait"]
    #subprocess.run(wait_args, stdout=subprocess.DEVNULL,
    #               stderr=subprocess.DEVNULL)

    # subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # devices = instance["incus"]["devices"]
    # for device in devices:
    #     # print(device)
    #     type = devices[device]['type']
    #     host_name = devices[device]['host_name']
    #     network = devices[device]['network']
    #     hwaddr = devices[device].get("hwaddr")

    #     # print(type)
    #     # print(host_name)
    #     # print(network)
    #     args = ['incus', 'config', 'device', 'add', name, device,
    #             type, f'host_name={host_name}', f'network={network}']
    #     if hwaddr is not None:
    #         args.append(f'hwaddr={hwaddr}')

    #     # print(args)
    #     subprocess.run(args)


def startInstance(instance):
    args = ['incus', 'start', instance]
    subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def stopInstance(instance):
    args = ['incus', 'stop', instance]
    subprocess.run(args)


def delete(instance, force=False):
    args = ['incus', 'delete', instance]
    if force:
        args.append('-f')
    subprocess.run(args)


def filePush(src_path, instance, recursive=True, logger=None):
    files = list(Path(src_path).iterdir())
    for file in files:
        args = ['incus', 'file', 'push', str(file), f"{instance}/", '-r']
        if logger:
            logger.info(f"Pushing {str(file)}")
        subprocess.run(args)


def filePull(instance, src_path, dst_path, logger=None):
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    args = ['incus', 'file', 'pull', f'{instance}{src_path}', dst_path]
    subprocess.run(args)
    if logger:
        logger.info(f"File {instance}{src_path} saved in {dst_path}")
