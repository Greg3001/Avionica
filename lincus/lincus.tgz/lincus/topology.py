import json
import yaml
import os

from config import LABS_PATH, IMAGES_PRIORITIES
from pyncus import pyncus
from collections import OrderedDict

def get_priority(instance):
    alias = instance.get("incus", {}).get("source", {}).get("alias", "")
    return IMAGES_PRIORITIES.get(alias, 99)

def start(scenario, logger=None):
    topology_path = os.path.join(LABS_PATH, scenario, 'topology.yaml')
    with open(topology_path) as f:
        topology = yaml.safe_load(f)

    # Create networks
    networks = topology["networks"]
    for net in networks:
        pyncus.createNetwork(net, 'bridge', {
            'ipv4.address': 'none',
            'ipv6.address': 'none'
        })
        if logger:
            logger.info(f"Network {net} created.")

    # Create and start instances
    instances = topology["instances"]

    # Creamos una lista de pares clave-valor ordenada por prioridad
    sorted_items = sorted(instances.items(), key=lambda item: get_priority(item[1]))

    # Mantenerlo como diccionario
    sorted_instances = OrderedDict(sorted_items)
    instances = sorted_instances

    for instance in instances:
        network_config_path = os.path.join(
            LABS_PATH, scenario, instance, 'network-config.yaml')
        with open(network_config_path) as f:
            network_config = yaml.safe_load(f)

        # user_data_path = os.path.join(
        #     LABS_PATH, scenario, instance, 'user-data.yaml')
        # with open(user_data_path) as f:
        #     user_data = yaml.safe_load(f)

        # Create instance
        pyncus.createInstance(
            instance, instances[instance], network_config_path)#, user_data_path)
        if logger:
            logger.info(f"Instance {instance} created.")

        # Push files
        instance_fs = os.path.join(LABS_PATH, scenario, instance)
        pyncus.filePush(instance_fs, instance,logger=logger)

        # Start instances
        pyncus.startInstance(instance)
        if logger:
            logger.info(f"Instance {instance} started")


def stop(scenario, logger=None):
    topology_path = os.path.join(LABS_PATH, scenario, 'topology.yaml')
    with open(topology_path) as f:
        topology = yaml.safe_load(f)

    # Stop instances
    instances = topology["instances"]
    for instance in instances:
        pyncus.stopInstance(instance)
        if logger:
            logger.info(f"Instance {instance} stopped")

    # Delete networks
    networks = topology['networks']
    for network in networks:
        pyncus.deleteNetwork(network)
        if logger:
            logger.info(f'Network {network} deleted')
