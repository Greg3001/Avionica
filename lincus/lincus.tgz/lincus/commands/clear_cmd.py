import subprocess
import re
import os

from config import CLR_REGEXP, LABS_PATH
from db.db_lincus import reset_running_scenario


def register_subcommand(subparsers):
    # Registrar el subcomando "clear"
    parser = subparsers.add_parser(
        "clear",
        description="Attempt to clear any network/instance not deleted",
        help="Clears lincus state"
    )


def execute(args, logger):
    args = ["incus", "list", "-c", "n", "-f", "csv"]
    result = subprocess.run(args, capture_output=True, text=True, check=True)

    # Filtrar las líneas que coincidan con alguna regexp en CLR_REGEXP["instances"]
    instances = [
        line.strip()
        for line in result.stdout.strip().splitlines()
        if any(re.fullmatch(pattern, line.strip()) for pattern in CLR_REGEXP["instances"])
    ]
    for instance in instances:
        args = ["incus", "delete", instance, "-f"]
        subprocess.run(args)
        logger.info(f"Instance {instance} deleted.")

    args = ["incus", "network", "list", "-f", "csv"]
    result = subprocess.run(args, capture_output=True, text=True, check=True)

    # Filtrar solo los nombres de red (primera columna) que hagan match con las regexp
    matches = []
    for line in result.stdout.strip().splitlines():
        first_column = line.strip().split(",")[0]
        if any(re.fullmatch(pattern, first_column) for pattern in CLR_REGEXP["networks"]):
            matches.append(first_column)

    for network in matches:
        args = ["incus", "network", "delete", network]
        subprocess.run(args)
        logger.info(f"Network {network} deleted.")

    try:
        db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
        scenario=reset_running_scenario(db_path)
    except RuntimeError as e:
        logger.error("Error updating database: {e}")

    logger.info("Lincus cleared.")