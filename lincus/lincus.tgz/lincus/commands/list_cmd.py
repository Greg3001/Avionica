import os
import sqlite3
from config import LABS_PATH
from prettytable import PrettyTable


def register_subcommand(subparsers):
    # Registrar el subcomando "list"
    parser = subparsers.add_parser(
        "list",
        description="Lists installed scenarios",
        help="Lists installed scenarios"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show all fields in the table"
    )

    parser.set_defaults(func=execute)


def execute(args, logger):
    db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        if args.verbose:
            cursor.execute("SELECT ID, RUNNING, TITLE, PATH FROM SCENARIOS ORDER BY ID COLLATE NOCASE")
            columns = ["ID", "RUNNING", "TITLE", "PATH"]
        else:
            cursor.execute("SELECT ID, RUNNING, TITLE FROM SCENARIOS ORDER BY ID COLLATE NOCASE")
            columns = ["ID", "RUNNING", "TITLE"]
        
        rows = cursor.fetchall()
        conn.close()
        
        if not rows:
            logger.info("No scenarios found.")
            return
        
        table = PrettyTable(columns)
        for row in rows:
            row = list(row)
            row[1] = "*" if row[1] else "-"  # Modificar RUNNING
            table.add_row(row)
        
        print(table)
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")