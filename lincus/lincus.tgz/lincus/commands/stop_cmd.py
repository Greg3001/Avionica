import topology
import os
from config import LABS_PATH
from db.db_lincus import reset_running_scenario

def register_subcommand(subparsers):
    # Registrar el subcomando "stop"
    parser = subparsers.add_parser(
        "stop",
        description="Stops running scenario",
        help="Stops running scenario"
    )

    # parser.add_argument(
    #     "scenario",
    #     help="Scenario id"
    # )

def execute(args, logger):
    try:
        db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
        scenario=reset_running_scenario(db_path)
        if scenario:
            topology.stop(scenario, logger)
            logger.info(f"Scenario {scenario} stopped")
        else:
            logger.warning(f"No scenario is running")
    except RuntimeError as e:
        logger.error("Error updating database: {e}")
