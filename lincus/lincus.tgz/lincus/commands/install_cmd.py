import sqlite3
import json
import yaml
import os
import shutil
import tarfile
import tempfile

from pathlib import Path
from config import LABS_PATH
from util import query_yes_no


def register_subcommand(subparsers):
    # Registrar el subcomando "install"
    parser = subparsers.add_parser(
        "install",
        description="Installs a lincus scenario.",
        help="Installs a lincus scenario."
    )

    # Argumentos para el subcomando
    parser.add_argument(
        "scenario",
        help="scenario file (tgz)"
    )

    parser.set_defaults(func=execute)


def execute(args, logger):
    scenario_file = args.scenario
    # Verificar si el archivo existe
    if not os.path.isfile(scenario_file):
        logger.error(f"File {scenario_file} not found")
        return

    # Create database if it doesn't exist. (TODO: Move to the installation script)
    db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
    try:
        # Conectar a la base de datos
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Crear la tabla SCENARIOS si no existe
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS SCENARIOS (
                ID TEXT PRIMARY KEY, 
                PATH TEXT NOT NULL, 
                RUNNING BOOLEAN DEFAULT FALSE, 
                TITLE TEXT
            );
        ''')

        # Asegurarse de que los cambios se apliquen
        conn.commit()

        # Cerrar la conexión
        conn.close()

    except sqlite3.Error as e:
        logger.error(f"Error connecting to database: {e}")
        return

    # Verificar si el archivo es un archivo .tgz válido
    try:
        with tarfile.open(args.scenario, 'r:gz') as tgz:
            # Crear un directorio temporal para descomprimir el archivo
            with tempfile.TemporaryDirectory() as temp_dir:
                logger.info(
                    f"Uncompressing scenario in temporary directory: {temp_dir}")

                # Extraer todos los archivos del .tgz al directorio temporal
                tgz.extractall(path=temp_dir)

                # Buscar el archivo scenario.json en cualquier subdirectorio
                scenario_file = None
                for path in Path(temp_dir).rglob('scenario.yaml'):
                    scenario_file = path
                    break  # Solo necesitamos el primer archivo encontrado

                if not scenario_file:
                    logger.error(
                        f"File 'scenario.yaml' not found in {args.scenario}.")
                    return

                # Cargar el archivo yaml y convertirlo a un diccionario
                with open(scenario_file) as fscenario:
                    scenario = yaml.safe_load(fscenario)
                    logger.info(
                        f"scenario.yaml sucessfully loaded")

                # Get scenario data
                id = scenario['id']
                title = scenario['title']

                scenario_path = f'{LABS_PATH}/{id}'
                if os.path.isdir(scenario_path):
                    answer = query_yes_no(
                        f'An scenario with the same id ({id}) already exists. Do you want to overwrite it?', default="yes")
                    if not answer:
                        logger.info('Installation aborted.')
                        return
                    else:
                        shutil.rmtree(scenario_path)
                shutil.copytree(temp_dir, LABS_PATH, dirs_exist_ok=True)

                # Insert/Update scenario in database
                try:
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()

                    cursor.execute('''
                        INSERT INTO SCENARIOS (ID, PATH, RUNNING, TITLE) 
                        VALUES (?, ?, FALSE, ?) 
                        ON CONFLICT(ID) DO UPDATE SET 
                            PATH = excluded.PATH, 
                            TITLE = excluded.TITLE, 
                            RUNNING = FALSE;
                    ''', (id, scenario_path, title))

                    conn.commit()
                    conn.close()
                    logger.info(f"Scenario {id} successfully recorded in database.")

                except sqlite3.Error as e:
                    shutil.rmtree(scenario_path)
                    logger.error(f"Database error: {e}")
                    logger.error("Scenario not installed")

                logger.info(
                    f'Scenario {id} installed. Execute lincus start {id} to start it.')
    except tarfile.TarError:
        logger.error(f"File {args.scenario} is not a valid tgz file.")
        return

    logger.info(f"Scenario {args.scenario} installed")
