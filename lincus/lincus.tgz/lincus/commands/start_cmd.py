import os
import sqlite3
import argcomplete

import topology
from config import LABS_PATH
from commands import stop_cmd
from db.db_lincus import set_scenario_running, does_scenario_exist


def register_subcommand(subparsers):
    # Registrar el subcomando "start"
    parser = subparsers.add_parser(
        "start",
        description="Starts an scenario",
        help="Starts an scenario"
    )

    parser.add_argument(
        "scenario",
        help="Scenario id"
    )

    parser.add_argument(
        "-f", "--force",
        action="store_true",
        help="Forces scenario to start, stopping running scenario (if any)"
    )

    parser.set_defaults(func=execute)
    #argcomplete.autocomplete(parser)


def execute(args, logger):
    if args.force:
        stop_cmd.execute(args, logger)
    db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
    try:
        if not does_scenario_exist(db_path, args.scenario):
            logger.error(f"Scenario {args.scenario} does not exist.")
            return

        if set_scenario_running(db_path, args.scenario):
            logger.info(f"Starting {args.scenario}")
            topology.start(args.scenario, logger)
            logger.info(f"Scenario {args.scenario} started")
        else:
            logger.error(
                f"There is a scenario running. Use --force to stop running scenario and start {args.scenario} again.")
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")
