import os
import yaml

from db.db_lincus import get_running_scenario, get_scenario_path
from config import LABS_PATH, IMAGES_NCM
from pyncus import pyncus
from utils.yaml_utils import setup_multiline_str
from utils.netplan import interfaces_to_netplan

import tarfile
from datetime import datetime
from pathlib import Path
import subprocess

setup_multiline_str()


def register_subcommand(subparsers):
    # Registrar el subcomando "stop"
    parser = subparsers.add_parser(
        "save",
        description="Saves running scenario",
        help="Saves running scenario"
    )


def execute(args, logger):
    try:
        db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
        scenario_id = get_running_scenario(db_path)

        if scenario_id:
            path = get_scenario_path(db_path, scenario_id)
            scenario_path = os.path.join(LABS_PATH, path, 'scenario.yaml')
            with open(scenario_path) as f:
                scenario = yaml.safe_load(f)

            # save network configuration manager
            topology_path = os.path.join(LABS_PATH, path, 'topology.yaml')
            with open(topology_path) as f:
                topology = yaml.safe_load(f)

            instances = topology["instances"]
            for instance_name, instance in topology['instances'].items():
                instance_rootfs = os.path.join(
                    LABS_PATH, scenario_id, instance_name)
                alias = instance.get('incus', {}).get(
                    'source', {}).get('alias')
                ncm = IMAGES_NCM[alias]
                if ncm == "ifupdown":
                    file = '/etc/network/interfaces'
                    dst_path = os.path.join(
                        instance_rootfs, file.lstrip('/'))
                    pyncus.filePull(instance_name, file,
                                    dst_path, logger=logger)
                    with open(dst_path, 'r') as f:
                        config = f.read()
                    network_config_store = interfaces_to_netplan(config)

                    network_config_yaml_path = os.path.join(
                        instance_rootfs, 'network-config.yaml')
                    with open(network_config_yaml_path, 'w') as f:
                        yaml.dump(network_config_store, f,
                                  default_flow_style=False, sort_keys=False)

            # backup files
            backup = scenario["backup"]
            instances = backup["instances"]

            for instance_name, saves in instances.items():
                instance_rootfs = os.path.join(
                    LABS_PATH, scenario_id, instance_name)

                for save in saves:
                    for directory in save.get("dirs", []):
                        pass  # TODO: procesar directorio

                    for file in save.get("files", []):
                        dst_path = os.path.join(
                            instance_rootfs, file.lstrip('/'))
                        if file.strip() == "/etc/frr/frr.conf":
                            args_wm = ["incus", "exec", instance_name,
                                 "--", "vtysh", "-c", "w m"]
                            print(args_wm)
                            subprocess.run(args_wm)
                        pyncus.filePull(instance_name, file,
                                        dst_path, logger=logger)
                        write_to_user_data(instance_rootfs, dst_path, file)

            to_compress = os.path.join(LABS_PATH, path)
            compress_scenario(to_compress, scenario_id)
            logger.info(f"Scenario {scenario_id} saved. Path = {path}")
        else:
            logger.warning(f"No scenario is running")
    except RuntimeError as e:
        logger.error("Error updating database: {e}")


def write_to_user_data(instance_rootfs, dst_path, path):
    yaml_path = os.path.join(
        instance_rootfs, 'user-data.yaml')
    with open(dst_path, 'r') as f:
        new_content = f.read()

    # Comprobar si el YAML existe
    if os.path.exists(yaml_path):
        with open(yaml_path, 'r') as f:
            lines = f.readlines()

        if lines and lines[0].strip() == "#cloud-config":
            cloud_config_header = lines[0]
            yaml_data = yaml.safe_load("".join(lines[1:])) or {}
        else:
            # YAML corrupto o sin encabezado válido
            cloud_config_header = "#cloud-config\n"
            yaml_data = {}
    else:
        cloud_config_header = "#cloud-config\n"
        yaml_data = {}

    # Asegurar que write_files está presente y es una lista
    write_files = yaml_data.get("write_files", [])

    # Ver si ya existe un bloque con ese path
    existing = next(
        (item for item in write_files if item.get("path") == path), None)

    if existing:
        existing["content"] = new_content
    else:
        write_files.append({
            "path": path,
            "content": new_content
        })

    # Actualizar el YAML con la nueva sección
    yaml_data["write_files"] = write_files

    # Guardar el YAML con encabezado
    with open(yaml_path, 'w') as f:
        f.write(cloud_config_header)
        yaml.dump(yaml_data, f, default_flow_style=False, sort_keys=False)


def compress_scenario(to_compress: str, scenario_id: str):
    # Generar nombre por defecto
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    default_filename = f"{scenario_id}-{timestamp}.tgz"
    home = str(Path.home())
    default_output_path = os.path.join(home, default_filename)

    print(f"\nEl archivo se guardará como: {default_output_path}")
    user_input = input(
        "¿Quieres dar un nombre personalizado al fichero TGZ? (s/N): ").strip().lower()

    # Usar nombre personalizado si el usuario lo desea
    if user_input == "s":
        filename = input(
            "Introduce el nombre del fichero (sin extensión .tgz): ").strip()
        if not filename:
            print("Nombre vacío, usando nombre automático.")
            filename = default_filename
        else:
            if not filename.endswith(".tgz"):
                filename += ".tgz"
    else:
        filename = default_filename

    output_path = os.path.join(home, filename)

    # Raíz del TGZ: solo el último componente del path (e.g. "L01-E02")
    arcname_root = os.path.basename(to_compress)

    with tarfile.open(output_path, "w:gz") as tar:
        tar.add(to_compress, arcname=arcname_root)

    print(f"\n✅ Archivo comprimido creado en: {output_path}")
    return output_path
