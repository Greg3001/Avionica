import sqlite3
import shutil
import os

from config import LABS_PATH

def register_subcommand(subparsers):
    # Registrar el subcomando "install"
    parser = subparsers.add_parser(
        "uninstall",
        description="Uninstalls a lincus scenario.",
        help="Uninstalls a lincus scenario."
    )

    # Argumentos para el subcomando
    parser.add_argument(
        "scenario",
        help="scenario id"
    )

    parser.set_defaults(func=execute)

def execute(args, logger):
    scenario_id = args.scenario
    
    db_path = os.path.join(LABS_PATH, 'lincus-scenarios.db')
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Buscar el escenario por ID
    cursor.execute('SELECT PATH FROM SCENARIOS WHERE ID = ?', (scenario_id,))
    result = cursor.fetchone()

    if result is None:
        logger.error(f"Scenario with ID '{scenario_id}' does not exist.")
        conn.close()
        return
    
    path = result[0]

    # Eliminar el directorio si existe
    if os.path.isdir(path):
        shutil.rmtree(path)
        logger.info(f"Deleted directory: {path}")
    else:
        logger.warning(f"Directory not found: {path}")

    # Eliminar el registro de la base de datos
    cursor.execute('DELETE FROM SCENARIOS WHERE ID = ?', (scenario_id,))
    conn.commit()
    logger.info(f"Deleted scenario from database: {scenario_id}")

    conn.close()